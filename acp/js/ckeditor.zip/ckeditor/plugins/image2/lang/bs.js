﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'bs', {
	alt: 'Tekst na slici',
	btnUpload: 'Šalji na server',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Info slike',
	lockRatio: 'Zakljuèaj odnos',
	menu: 'Svojstva slike',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Resetuj dimenzije',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Svojstva slike',
	uploadTab: 'Šalji',
	urlMissing: 'Image source URL is missing.' // MISSING
} );
